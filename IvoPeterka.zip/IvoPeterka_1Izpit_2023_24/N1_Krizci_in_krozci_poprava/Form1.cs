﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace N1_Krizci_in_krozci_poprava
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            InicializirajGumbe();
        }
       

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private bool naPoteziX = true; // Ali je na potezi X ali O
        private bool konecIgre = false; // Ali je igre konec

       

        // Metoda za inicializacijo gumbov v igralnem polju, tu sem si pomagal z chatGPT
        private void InicializirajGumbe()
        {
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Button button = new Button();
                    button.Name = "button_" + i + "_" + j;
                    button.Size = new System.Drawing.Size(100, 100);
                    button.Location = new System.Drawing.Point(j * 100, i * 100);
                    button.Font = new System.Drawing.Font("Arial", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                    button.Click += new EventHandler(Button_Click);
                    Controls.Add(button);
                }
            }
        }

        // Metoda, ki se sproži ob kliku na gumb
        private void Button_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;

            // Preverimo, ali je gumb prazen in ali je igre konec
            if (button.Text == "" && !konecIgre)
            {
                button.Text = naPoteziX ? "X" : "O"; // Postavimo X ali O na gumb
                naPoteziX = !naPoteziX; // Preklopimo igralca
                PreveriKonecIgre();
            }
        }

        // Metoda za preverjanje konca igre
        private void PreveriKonecIgre()
        {
            // Preverimo zmagovalne kombinacije v vrsticah, stolpcih in diagonalah
            for (int i = 0; i < 3; i++)
            {
                if (ProveriZmagovalnoKombinacijo(button_0_0.Text, button_0_1.Text, button_0_2.Text)
                    || ProveriZmagovalnoKombinacijo(button_1_0.Text, button_1_1.Text, button_1_2.Text)
                    || ProveriZmagovalnoKombinacijo(button_2_0.Text, button_2_1.Text, button_2_2.Text)
                    || ProveriZmagovalnoKombinacijo(button_0_0.Text, button_1_0.Text, button_2_0.Text)
                    || ProveriZmagovalnoKombinacijo(button_0_1.Text, button_1_1.Text, button_2_1.Text)
                    || ProveriZmagovalnoKombinacijo(button_0_2.Text, button_1_2.Text, button_2_2.Text)
                    || ProveriZmagovalnoKombinacijo(button_0_0.Text, button_1_1.Text, button_2_2.Text)
                    || ProveriZmagovalnoKombinacijo(button_0_2.Text, button_1_1.Text, button_2_0.Text))
                {
                    konecIgre = true;
                    MessageBox.Show((naPoteziX ? "O" : "X") + " je zmagal!");
                    return;
                }
            }

           
        }

        // Metoda za preverjanje zmagovalnih kombinacij
        private bool ProveriZmagovalnoKombinacijo(string a, string b, string c)
        {
            return a == b && b == c && a != "";
        }

        private void button_0_0_Click(object sender, EventArgs e)
        {

        }
        
    }
}
    


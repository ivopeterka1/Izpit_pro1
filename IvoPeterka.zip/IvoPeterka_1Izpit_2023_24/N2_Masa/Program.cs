﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace N2_Masa
{
    public class Masa
    {
        private int koliko; // Količina mase
        private string enota; // Merska enota

        // Lastnost za dostop do količine mase
        public int Koliko
        {
            get { return koliko; }
            set
            {
                if (value < 0)
                    throw new ArgumentException("Količina mase ne more biti negativna.");
                koliko = value;
            }
        }

        // Lastnost za dostop do merske enote
        public string Enota
        {
            get { return enota; }
            set
            {
                // Preverimo, ali je enota med dovoljenimi
                if (value != "kg" && value != "dag" && value != "funt" && value != "g")
                    throw new ArgumentException("Neveljavna enota mase.");
                enota = value;
            }
        }

        // Konstruktor razreda Masa
        public Masa(int koliko, string enota)
        {
            Koliko = koliko;
            Enota = enota;
        }

        // Metoda, pretvorbo enote v grame
        public static double Faktor(string enota)
        {
            switch (enota)
            {
                case "kg":
                    return 1000;
                case "dag":
                    return 10;
                case "funt":
                    return 453.592;

                default: // če je "g"
                    return 1;
            }
        }

        // Preoblikovanje Masa objekta v niz oblike "12.3 dag"
        public override string ToString()
        {
            return $"{koliko} {enota}";
        }

        // Metoda, ki vrne največjo maso iz dane tabele mas
        public static Masa[] NajvecjaMasa(Masa[] mase)
        {
            // Pretvorimo mase v gramih
            double[] maseVGramih = mase.Select(m => m.Koliko * Faktor(m.Enota)).ToArray();
            // Najdemo največjo maso
            double največjaMasaVGramih = maseVGramih.Max();
            // Izberemo mase, ki imajo največjo maso
            return mase.Where(m => m.Koliko * Faktor(m.Enota) == največjaMasaVGramih).ToArray();
        }

        // Metoda, ki vrne skupno maso v najpogostejši enoti
        public static Masa Sestej(Masa[] mase)
        {
            // Izračunamo skupno maso v gramih
            double skupnaMasaVGramih = mase.Sum(m => m.Koliko * Faktor(m.Enota));
            // Najdemo najpogostejšo enoto
            var najpogostejšaEnota = mase.GroupBy(m => m.Enota).OrderByDescending(grp => grp.Count()).First().Key;
            // Zaokrožimo in pretvorimo skupno maso v najpogostejši enoti
            int skupnaMasa = (int)Math.Round(skupnaMasaVGramih / Faktor(najpogostejšaEnota));
            // Vrnemo novo maso
            return new Masa(skupnaMasa, najpogostejšaEnota);
        }
    }

    class Program
    {
        static void Main()
        {
            Random random = new Random();
            Masa[] mase = new Masa[20];

            // Ustvari tabelo velikosti 20 in jo napolni simetrično z naključnimi masami in enotami
            for (int i = 0; i < mase.Length / 2; i++)
            {
                int koliko = random.Next(1, 100);
                string[] enote = { "kg", "dag", "funt", "g" };
                string enota = enote[random.Next(enote.Length)];
                mase[i] = new Masa(koliko, enota);
                mase[mase.Length - 1 - i] = new Masa(koliko, enota);
            }

            // Izpiši maso, ki je vsota mas te tabele
            Console.WriteLine("Masa, ki je vsota mas te tabele: " + Masa.Sestej(mase));

            

            // Ponovno izpiši maso, ki je vsota mas te dane tabele po povečanju prvega elementa
            Console.WriteLine("Masa, ki je vsota mas te dane tabele po povečanju prvega elementa: " + Masa.Sestej(mase));
        }
    }
}

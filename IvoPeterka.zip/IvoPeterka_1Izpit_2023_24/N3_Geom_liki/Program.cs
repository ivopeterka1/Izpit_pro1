﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace N3_Geom_liki
{

    /// <summary>
    /// Vmesnik, ki določa metodo Ploscina, ki jo morajo implementirati vsi geometrijski liki.
    /// </summary>odo Ploscina, ki jo morajo implementirati vsi geometrijski liki
    public interface IGeomLik
    {
        double Ploscina();
    }

    // razred Krog, ki implementira vmesnik IComparable<Krog> za primerjanje krogov
    public class Krog : IComparable<Krog>
    {
        // lastnosti za polmer, središče
        public int Polmer { get; set; }
        public int Sx { get; set; }
        public int Sy { get; set; }

        /// <summary>
        /// Konstruktor razreda Krog.
        /// </summary>
        /// <param name="polmer">Polmer kroga.</param>
        /// <param name="sx">Koordinata središča kroga v smeri x.</param>
        /// <param name="sy">Koordinata središča kroga v smeri y.</param>
        public Krog(int polmer, int sx, int sy)
        {
            if (polmer <= 0)
            {
                throw new ArgumentException("Polmer mora biti pozitivno celo število.");
            }
            Polmer = polmer;
            Sx = sx;
            Sy = sy;
        }

        /// <summary>
        /// Izračuna ploščino kroga.
        /// </summary>
        /// <returns>Ploščina kroga.</returns>
        public double Ploscina()
        {
            return Math.PI * Polmer * Polmer;
        }

        // metoda za izračun ploščine kroga
        public double Obseg()
        {
            return 2 * Math.PI * Polmer;
        }

        // Metoda za primerjanje krogov po ploščini
        public int CompareTo(Krog drugi)
        {
            if (drugi == null) return 1;
            return this.Ploscina().CompareTo(drugi.Ploscina());
        }

        /// <summary>
        /// Metoda za preverjanje ali je dani krog približno enak temo krogu z določeno toleranco
        /// </summary>
        /// <param name="drugi"></param>
        /// <param name="toleranca"></param>
        /// <returns>Vrne true ali false</returns>
        public bool SemEnak(Krog drugi, double toleranca)
        {
            return Math.Abs(this.Ploscina() - drugi.Ploscina()) < toleranca;
        }

        // Metoda, ki sprejme objekt, vplementira vmesnik IgeomLik in vrne nov krog z enako ploščino
        public static Krog Spremeni(IGeomLik objekt)
        {
            Random rnd = new Random();
            double ploscina = objekt.Ploscina(); // Izračunamo ploščino podanega geometrijskega lika
            int polmer = (int)Math.Sqrt(ploscina / Math.PI); // IZračunamo polmer novega kroga iz ploščine
            int sx = rnd.Next(-100, 101);
            int sy = rnd.Next(-100, 101);

            return new Krog(polmer, sx, sy); // Vrnemo nov krog
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Ustvarimo nekaj primerov krogov
            Krog krog1 = new Krog(5, 0, 0);
            Krog krog2 = new Krog(7, 2, 3);

            // Primerjava ploščin krogov
            double tolerance = 0.01; // Določimo toleranco
            bool enaka = krog1.SemEnak(krog2, tolerance); // Preverimo, ali sta kroga približno enaka

            // Izpis rezultata primerjave
            if (enaka)
            {
                Console.WriteLine("Kroga sta približno enaka.");
            }
            else
            {
                Console.WriteLine("Kroga se razlikujeta.");
            }
        }
    }
}
